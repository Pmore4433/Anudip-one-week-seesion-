package Practice;

public class Customers {
	private String name;
    private String account;
    private int number;
			
    public String getName() {
		return name;
	}
    public void setName(String name) {
	this.name = name;
	}
    public String getAccount() {
	return account;
	}
	public void setAccount(String account) {
	this.account = account;
	}
	public int getNumber() {
	return number;
	}
	public void setNumber(int number) {
	this.number = number;
	}
			
	// Methods
	public String getAccountNumber() {
		 return account;
		}

		    public String getCName() {
		        return name;
		    }
			 
	
	

}
